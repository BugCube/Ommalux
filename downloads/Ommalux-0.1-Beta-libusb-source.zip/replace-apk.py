# SPDX-License-Identifier: LGPL-2.1-or-later
"""Create an unsigned APK copy containing user-rebuilt libusb shared libraries."""
import argparse
from pathlib import Path
import struct
from zipfile import ZipFile

ELF_TARGETS = {"arm64-v8a": (2, 183), "armeabi-v7a": (1, 40), "x86": (1, 3), "x86_64": (2, 62)}


def signature_entry(name):
    upper = name.upper()
    return upper.startswith("META-INF/") and (
        upper == "META-INF/MANIFEST.MF" or upper.endswith((".SF", ".RSA", ".DSA", ".EC"))
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", type=Path, required=True, help="Original standalone/universal APK")
    parser.add_argument("--libraries", type=Path, required=True, help="Build output with ABI subdirectories")
    parser.add_argument("--output", type=Path, required=True, help="New unsigned APK path")
    args = parser.parse_args()
    source = args.apk.resolve()
    output = args.output.resolve()
    if source == output or output.exists():
        parser.error("Choose a new output file")
    replacements = {}
    for abi, target in ELF_TARGETS.items():
        library = args.libraries / abi / "libusb1.0.so"
        if not library.is_file():
            continue
        data = library.read_bytes()
        if len(data) < 20 or data[:4] != b"\x7fELF" or data[5] != 1:
            parser.error("Invalid little-endian ELF library: " + str(library))
        if (data[4], struct.unpack_from("<H", data, 18)[0]) != target:
            parser.error("Library ABI differs from its directory: " + str(library))
        replacements["lib/" + abi + "/libusb1.0.so"] = data
    if not replacements:
        parser.error("No rebuilt libusb libraries found")
    with ZipFile(source) as original:
        missing = replacements.keys() - set(original.namelist())
        if missing:
            parser.error("APK does not contain the requested ABI entries: " + ", ".join(sorted(missing)))
        output.parent.mkdir(parents=True, exist_ok=True)
        archive = ZipFile(output, "x")
        try:
            with archive:
                for entry in original.infolist():
                    if signature_entry(entry.filename):
                        continue
                    data = replacements.get(entry.filename)
                    if data is None:
                        data = original.read(entry)
                    archive.writestr(entry, data)
        except BaseException:
            output.unlink(missing_ok=True)
            raise
    print("Unsigned APK created: " + str(output))
    print("Replaced libraries: " + str(len(replacements)))
    print("Align and sign this APK with your own key before installation.")


if __name__ == "__main__":
    main()
