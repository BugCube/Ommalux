# libusb source and replacement

Prepared 14 November 2026 for Ommalux 0.1 (Beta), version code 1, application ID `org.ommalux.camera`.

## Download and scope

[Download the libusb source package](https://bugcube.github.io/Ommalux/downloads/Ommalux-0.1-Beta-libusb-source.zip)

The archive contains the Android libusb 1.0.25 fork from UVCAndroid 1.0.13, pinned to revision `6018c7f20238832929cf61427427bb7828056260`. It includes the complete tracked libusb subtree, Android configuration and original build scripts, COPYING, AUTHORS, a file-hash manifest, and the two supplementary helpers described below. The source's existing 16 KiB linker settings are retained.

The Ommalux native integration links libusb dynamically through `libusb1.0.so`. The four shipped library hashes are recorded in `source-manifest.json`. The reconstructed source builds retain all 91 exported symbols for each ABI, the same SONAME, and 16 KiB load alignment. A byte-identical reconstruction of the preserved original binaries has not been established.

The supplementary Python helpers carry LGPL-2.1-or-later identifiers. Upstream files retain their original notices and terms. The archive's file list is restricted to the library source and these distribution materials.

## License and permissions

Ommalux uses libusb under the GNU Lesser General Public License, version 2.1 or later. Its full license is provided in `libusb/COPYING` and the app's `libusb-COPYING` notice.

You may modify or replace the LGPL-covered libusb library for your own use. You may reverse engineer Ommalux as necessary to debug those library modifications, consistent with the applicable LGPL terms. The permissions and obligations for other components follow their respective licenses.

Sections 4 and 6 cover source delivery, notices and the available approaches for a combined work. The procedure below provides a source build and APK replacement route. Its host-side verification is recorded below. Android execution with a replacement library still needs device validation. [libusb LGPL text](https://raw.githubusercontent.com/libusb/libusb/v1.0.25/COPYING)

## Prerequisites

- Python 3.9 or newer.
- Android NDK. The checked build uses r27c, revision 27.2.12479018.
- Android SDK Build Tools with `zipalign` and `apksigner`. Validation used version 36.0.0.
- A JDK and your own APK-signing key for the replacement copy.
- An Ommalux APK you are entitled to use. For a split installation, follow the split-APK section.

Commands below run from the extracted source-package directory. Substitute your actual NDK, SDK tools and input APK paths. Tool arguments are shown independently of any project checkout.

## Build a compatible library

Modify the supplied source while preserving the public interfaces needed by Ommalux. Run the build helper with a separate output directory.

```text
python build.py --source libusb --ndk "/path/to/android-ndk-r27c" --output rebuilt
```

The default builds arm64-v8a, armeabi-v7a, x86 and x86_64. To build one ABI, add `--abi arm64-v8a`, substituting the required ABI. Each output is `rebuilt/<abi>/libusb1.0.so`.

The helper reproduces the supplied Android makefile's source selection and relevant flags. It uses Android API 21 native targets, preserves the `libusb1.0.so` SONAME and sets 16 KiB load alignment. The app's minimum Android version remains API 26. Android's NDK documentation describes target and host conventions. [NDK build guidance](https://developer.android.com/ndk/guides/other_build_systems)

For additional verification, use the NDK's `llvm-readelf` to inspect public exports, dynamic dependencies and ELF load alignment. Preserve the original public symbols and calling conventions for compatibility. Behavior can change according to your modifications.

## Replace the library in an APK copy

```text
python replace-apk.py --apk original.apk --libraries rebuilt --output replacement-unsigned.apk
```

The helper validates library architecture against its ABI directory and requires matching entries in the input APK. It creates a new unsigned APK, substitutes the available rebuilt libusb entries and copies other entries. Existing JAR signature files are removed, and the old APK signing block is discarded when rebuilding the ZIP. It rejects an existing output path.

Use a standalone/universal APK for this procedure. The app owner can obtain a universal APK from the app-bundle tools or Play Console. For an existing split installation, use the next section.

Align the replacement copy before signing.

```text
zipalign -P 16 4 replacement-unsigned.apk replacement-aligned.apk
apksigner sign --ks your-own-key.jks --out replacement-signed.apk replacement-aligned.apk
apksigner verify --verbose replacement-signed.apk
zipalign -c -P 16 4 replacement-signed.apk
```

The signing tool prompts for your private keystore credentials. Keep them private. Changing an APK after signing invalidates its signature, so complete replacements and alignment first. [Android APK signing tools](https://developer.android.com/tools/apksigner)

## Split APK installations

An installed Play build may contain a base APK and ABI/configuration splits. Obtain the package file paths from your device and copy each APK to your computer.

```text
adb shell pm path org.ommalux.camera
adb pull /path/reported/by/pm/base.apk original-splits/base.apk
```

Repeat the copy for every reported split. Identify which APK contains `lib/<abi>/libusb1.0.so`. Run `replace-apk.py` on that APK with the corresponding rebuilt ABI library. Keep the complete original split set and create separate output copies for the replacement installation.

Align and sign every output APK in that set with the same personal key, including copies of splits whose payloads are unchanged. Install the complete, consistently signed set with `adb install-multiple` on the intended test device/profile. All required base/configuration splits must be included. The standalone helper validates the APK it processes and does not automate split-set discovery or installation.

## Installation and data handling

Use a spare device, emulator or separate Android user profile to test your replacement copy. Its signer differs from the official Ommalux signer. Android therefore rejects an in-place update over an official installation using a different certificate.

In the same profile, replacing that installation may require uninstalling it, which removes private app settings, profiles and queued files. Export data you need and assess pending uploads before doing so. The supplied helpers perform no installation or uninstallation. External saved files have their storage destination's own retention behavior.

The current app has no active account or billing gate. Future releases that introduce signing-dependent services need a fresh compatibility review of this replacement route.

## Verification performed

- Built the supplied libusb source for all four ABIs using NDK r27c.
- Compared public dynamic symbols against each shipped `libusb1.0.so`, with all 91 original exports retained per ABI.
- Verified SONAME and at least 16 KiB PT_LOAD alignment.
- Built a separate modified source fixture with an added exported validation function.
- Replaced all four libusb entries in a copy of the debug APK.
- Aligned and signed that copy using an isolated, newly generated temporary test key, then verified v2/v3 signatures and ZIP alignment. The temporary private key was removed after validation.
- Compared APK payload entries and confirmed that only the four intended native libraries changed, apart from signing material.
- No Android device was connected. Installation, dynamic loading and camera operation with the modified library remain unverified.

## Maintaining source availability

Publish this versioned archive with the app information and keep the download accessible for recipients of this release. Retain the corresponding source/build materials and record updates when native libraries change. Generate a new source package and update the app notice and website link for changed releases. Keep historical packages available for their recipients.

The app notice points to the source page and versioned archive. The packaged `source-manifest.json` lists library source and helper hashes plus the reference ABI hashes. Validate those records before relying on a downloaded copy. The broader LGPL and dependency-review checklist remains subject to actual distribution and device verification.
