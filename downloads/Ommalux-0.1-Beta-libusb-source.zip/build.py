# SPDX-License-Identifier: LGPL-2.1-or-later
"""Build the supplied Android libusb fork as a replaceable shared library."""
import argparse
import os
from pathlib import Path
import platform
import subprocess

TARGETS = {
    "arm64-v8a": "aarch64-linux-android21",
    "armeabi-v7a": "armv7a-linux-androideabi21",
    "x86": "i686-linux-android21",
    "x86_64": "x86_64-linux-android21",
}
SOURCES = [
    "core.c", "descriptor.c", "hotplug.c", "io.c", "sync.c", "strerror.c",
    "os/linux_usbfs.c", "os/events_posix.c", "os/threads_posix.c",
    "os/linux_netlink.c",
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Supplied libusb directory")
    parser.add_argument("--ndk", type=Path, required=True, help="Android NDK directory")
    parser.add_argument("--output", type=Path, required=True, help="Separate build output directory")
    parser.add_argument("--abi", nargs="+", choices=TARGETS, default=list(TARGETS))
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    if output == source or output.is_relative_to(source):
        parser.error("Choose an output directory outside the supplied source tree")
    host = {"Windows": "windows-x86_64", "Linux": "linux-x86_64", "Darwin": "darwin-x86_64"}[platform.system()]
    suffix = ".exe" if os.name == "nt" else ""
    tools = args.ndk.resolve() / "toolchains/llvm/prebuilt" / host / "bin"
    compiler = tools / ("clang" + suffix)
    strip = tools / ("llvm-strip" + suffix)
    for path in [compiler, strip, source / "android/config.h", *[source / "libusb" / name for name in SOURCES]]:
        if not path.is_file():
            parser.error("Required build input is missing: " + str(path))
    for abi in args.abi:
        destination = output / abi
        destination.mkdir(parents=True, exist_ok=True)
        library = destination / "libusb1.0.so"
        pending = destination / "libusb1.0.so.pending"
        command = [
            str(compiler), "--target=" + TARGETS[abi], "-shared", "-fPIC", "-O3",
            "-std=gnu11", "-fvisibility=hidden", "-pthread", "-DANDROID_NDK",
            "-DACCESS_RAW_DESCRIPTORS", "-fstrict-aliasing", "-fprefetch-loop-arrays",
            "-I" + str(source / "android"), "-I" + str(source / "libusb"),
            "-I" + str(source / "libusb/os"),
        ]
        if abi == "armeabi-v7a":
            command.append("-marm")
        command.extend(str(source / "libusb" / name) for name in SOURCES)
        command.extend([
            "-llog", "-Wl,-soname,libusb1.0.so", "-Wl,-z,max-page-size=16384",
            "-Wl,-z,common-page-size=16384", "-Wl,--no-undefined", "-o", str(pending),
        ])
        print("Building " + abi, flush=True)
        try:
            subprocess.run(command, check=True)
            subprocess.run([str(strip), "--strip-unneeded", str(pending)], check=True)
            pending.replace(library)
        finally:
            pending.unlink(missing_ok=True)
        print(library, flush=True)


if __name__ == "__main__":
    main()
